﻿namespace P03_FootballBetting.Data
{
    public class Config
    {
        public const string ConnectionString =
            "Server=BACELAPTOP\\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
    }
}