﻿namespace BillsPaymentSystem.Data
{
    internal class Config
    {
        internal static string ConnectionString = "Server=BACELAPTOP\\SQLEXPRESS;Database=BillPaymentSystem;Integrated Security=True";
    }
}