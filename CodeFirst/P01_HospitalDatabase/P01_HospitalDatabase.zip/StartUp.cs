﻿namespace P01_HospitalDatabase
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //using (var db = new HospitalContext())
            //{
            //    db.Database.EnsureCreated();
            //}
        }
    }
}