﻿namespace P01_HospitalDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server=BACELAPTOP\SQLEXPRESS;Database=Hospital;Integrated Security=SSPI";
    }
}